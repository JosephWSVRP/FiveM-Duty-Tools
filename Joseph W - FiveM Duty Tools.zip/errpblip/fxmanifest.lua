fx_version 'bodacious'
game 'gta5'

author 'Your Name'
description 'Duty Blip Toggle for players'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'

-- Optional: For ensuring the resources load correctly


-- If you have a readme or documentation
files {
    'readme.md'
}

-- Ensure the client-side script can access the server-side commands
lua54 'yes'
