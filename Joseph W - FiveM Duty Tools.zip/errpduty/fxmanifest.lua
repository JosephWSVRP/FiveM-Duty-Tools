fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Duty Command System'
version '1.0.0'

client_script 'client.lua'
-- Uncomment the next line if you need server-side script for custom command registration
server_script 'server.lua'
